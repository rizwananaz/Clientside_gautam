$("#get").click(function(){
  $("#out").text("name=" + $("#name").val() + ", color=" + $("#color").val() + ", msg=" + $("#msg").val());
});
$("#set").click(function(){ $("#name").val("Bob"); $("#color").val("Blue"); $("#msg").val("Set by val()"); });
