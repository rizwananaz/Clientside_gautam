$(function(){
  $("#container").before("<p class='hint'>Inserted BEFORE container on ready</p>");
  $("#container").after("<p class='hint'>Inserted AFTER container on ready</p>");
});
var img = '<img alt="img" width="60" height="24" style="background:#fc9">';
$("#b").click(function(){ $("#title").before(img); });
$("#a").click(function(){ $("#title").after(img); });
$("#multi").click(function(){ $("p:not(.hint)").before("<h2>H2</h2>", "<p class='hint'>P</p>", img); });
