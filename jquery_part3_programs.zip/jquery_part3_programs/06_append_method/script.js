$(function(){ $("p").append(" <strong>(appended on ready)</strong>"); });
$("#btn").click(function(){ $("#container").append(" [appended text]"); });
$("#multi").click(function(){
  $("body").append("<h1>Heading</h1>", "<p>Paragraph</p>", '<img alt="img" width="60" height="30" style="background:#9cf">');
});
