$("#btn").click(function(){ $("p").unwrap(); });  // removes the parent div
