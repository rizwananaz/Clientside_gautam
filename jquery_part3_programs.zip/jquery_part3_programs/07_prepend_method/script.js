$(function(){ $("p").prepend("<strong>(prepended on ready)</strong> "); });
$("#btn").click(function(){ $("#container").prepend("[prepended text] "); });
$("#multi").click(function(){ $("body").prepend("<h1>Heading</h1>", "<p>Paragraph</p>"); });
