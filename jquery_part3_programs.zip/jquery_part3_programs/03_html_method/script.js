$("#get").click(function(){ $("#out").text($("#container").html()); });
$("#set").click(function(){ $("#container").html("<h3>New HTML</h3><p>Replaced <em>everything</em>.</p>"); });
