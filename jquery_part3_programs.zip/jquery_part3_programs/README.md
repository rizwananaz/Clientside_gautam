# jQuery Part Three - small programs

One folder per topic. Open each folder's `index.html` in a browser (jQuery is bundled, no internet needed).

- `01_getters_and_setters` - Getters & Setters
- `02_text_method` - text()
- `03_html_method` - html()
- `04_attr_method` - attr()
- `05_val_method` - val()
- `06_append_method` - append()
- `07_prepend_method` - prepend()
- `08_before_and_after` - before() & after()
- `09_wrap_method` - wrap()
- `10_empty_method` - empty()
- `11_remove_method` - remove()
- `12_unwrap_method` - unwrap()
- `13_removeAttr_method` - removeAttr()
- `14_addClass_removeClass` - addClass() & removeClass()
- `15_toggleClass_method` - toggleClass()
- `16_width_and_height` - width() & height()
- `17_innerWidth_and_innerHeight` - innerWidth() & innerHeight()
- `18_outerWidth_and_outerHeight` - outerWidth() & outerHeight()
