$("#add").click(function(){
  $("h1").addClass("page-header");
  $("p.hint").addClass("highlight");
});
$("#rem").click(function(){
  $("h1").removeClass("page-header");
  $("p").removeClass("hint highlight");   // several classes at once
});
