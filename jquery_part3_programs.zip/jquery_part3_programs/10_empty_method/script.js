$("#btn").click(function(){ $(".container").empty(); });  // boxes stay, children go
