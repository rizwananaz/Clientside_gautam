$("#get").click(function(){ $("#out").text("href: " + $("#link").attr("href") + " | alt: " + $("#pic").attr("alt")); });
$("#check").click(function(){ $("#chk").attr("checked", "checked").prop("checked", true); });
$("#multi").click(function(){
  $("#pic").attr({ "class": "highlight", "title": "Set via attr()" });
  $("#out").text("img title is now: " + $("#pic").attr("title"));
});
