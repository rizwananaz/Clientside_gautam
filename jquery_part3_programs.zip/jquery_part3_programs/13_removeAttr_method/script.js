$("#btn").click(function(){
  $("a").removeAttr("href");
  $("#out").text("href removed - links are no longer clickable.");
});
