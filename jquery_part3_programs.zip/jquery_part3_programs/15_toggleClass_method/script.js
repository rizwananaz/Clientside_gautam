$("#btn").click(function(){ $("#p").toggleClass("highlight"); });
