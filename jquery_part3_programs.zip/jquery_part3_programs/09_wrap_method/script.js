$("#btn").click(function(){ $("#container").wrap("<div class='wrapper'></div>"); });
$("#inner").click(function(){ $("p").contents().wrap("<b></b>").wrap("<em></em>"); });
