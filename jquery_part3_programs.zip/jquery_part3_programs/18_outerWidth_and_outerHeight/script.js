$("#get").click(function(){ $("#out").text("outerWidth: " + $("#box").outerWidth() + " | outerHeight: " + $("#box").outerHeight()); });
$("#margin").click(function(){ $("#out").text("outerWidth(true): " + $("#box").outerWidth(true) + " | outerHeight(true): " + $("#box").outerHeight(true)); });
$("#set").click(function(){ $("#box").outerWidth(400); $("#out").text("content width is now " + $("#box").width()); });
