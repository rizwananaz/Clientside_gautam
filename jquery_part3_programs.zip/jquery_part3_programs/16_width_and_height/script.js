$("#get").click(function(){ $("#out").text("width: " + $("#box").width() + " | height: " + $("#box").height()); });
$("#set").click(function(){ $("#box").width(400).height(300); });
