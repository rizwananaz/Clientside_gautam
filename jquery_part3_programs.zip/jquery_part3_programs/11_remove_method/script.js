$("#all").click(function(){ $("p.hint").remove(); });
$("#filter").click(function(){ $("p").remove(".hint, .demo"); });  // selector as filter
