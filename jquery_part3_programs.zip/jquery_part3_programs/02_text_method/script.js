$("#get").click(function(){ $("#out").text($("p").text()); });   // combined text of all p
$("#set").click(function(){ $("p:first").text("<i>Text is escaped</i> - new text!"); });
