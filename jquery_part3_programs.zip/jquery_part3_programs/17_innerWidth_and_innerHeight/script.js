$("#get").click(function(){ $("#out").text("innerWidth: " + $("#box").innerWidth() + " | innerHeight: " + $("#box").innerHeight()); });
// New content width = 400 - horizontal padding (50) = 350
$("#set").click(function(){ $("#box").innerWidth(400); $("#out").text("content width is now " + $("#box").width()); });
