$("#get").click(function(){
  $("#out").text("text(): " + $("#name").text() + " | val(): " + $("#field").val());
});
$("#set").click(function(){
  $("#name").text("Changed by a setter");
  $("#field").val("new value");
});
