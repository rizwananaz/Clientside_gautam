// Slide 8: length, and showing the whole array
registerExample(4, "Length and showing the whole array", function () {
  let fruits = ["Apple", "Orange", "Plum"];
  alert(fruits.length); // 3
  alert(fruits);        // Apple,Orange,Plum
});
