// Slide 12: shift & unshift - start of the array
registerExample(8, "shift & unshift (start of array)", function () {
  let fruits = ["Apple", "Orange", "Pear"];
  alert(fruits.shift()); // removes "Apple" and returns it
  alert(fruits);         // Orange,Pear

  let fruits2 = ["Orange", "Pear"];
  fruits2.unshift("Apple");
  alert(fruits2);        // Apple,Orange,Pear
});
