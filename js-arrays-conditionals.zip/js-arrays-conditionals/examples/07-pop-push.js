// Slide 11: pop & push - end of the array
registerExample(7, "pop & push (end of array)", function () {
  let fruits = ["Apple", "Orange", "Pear"];
  alert(fruits.pop()); // removes "Pear" and returns it
  alert(fruits);       // Apple,Orange

  let fruits2 = ["Apple", "Orange"];
  fruits2.push("Pear");
  alert(fruits2);      // Apple,Orange,Pear
});
