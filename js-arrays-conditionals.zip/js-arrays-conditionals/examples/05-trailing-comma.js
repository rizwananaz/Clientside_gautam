// Slide 9: Trailing comma
registerExample(5, "Trailing comma", function () {
  let fruits = [
    "Apple",
    "Orange",
    "Plum",   // <- trailing comma is allowed
  ];
  alert(fruits);
  alert("Length is still " + fruits.length + " (the trailing comma adds nothing)");
});
