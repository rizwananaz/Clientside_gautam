// Slides 4-5: Syntaxes for creating arrays
registerExample(2, "Creating arrays", function () {
  let arr1 = new Array(); // syntax 1 (rarely used)
  let arr2 = [];          // syntax 2 (used almost all the time)
  alert("arr1 length: " + arr1.length + ", arr2 length: " + arr2.length);

  // Supplying initial elements in the brackets
  let fruits = ["Apple", "Orange", "Plum"];
  alert("fruits: " + fruits);

  // Declared with var, let or const
  var a = [1, 2, 3];
  let b = ["x", "y"];
  const c = [true, false];
  alert("var: " + a + " | let: " + b + " | const: " + c);

  // Length and element types are NOT fixed
  let mixed = [42, "hello", true, null];
  mixed.push(3.14);
  alert("mixed types: " + JSON.stringify(mixed) + " (length " + mixed.length + ")");

  // Elements are numbered starting from zero
  alert("fruits[0] is the FIRST element: " + fruits[0]);
});
