// Slides 23-24: else and else if
registerExample(12, "else and else if", function () {
  let year = Number(prompt("In which year was ECMAScript 2015 published?", "2014"));

  // else
  if (year == 2015) {
    alert("You guessed it right!");
  } else {
    alert("How can you be so wrong?"); // any value except 2015
  }

  // else if
  if (year < 2015) {
    alert("Too early...");
  } else if (year > 2015) {
    alert("Too late");
  } else {
    alert("Exactly!");
  }
});
