// Slides 2-3: What is an array? Why do we need them?
registerExample(1, "What is an array? (invoice example)", function () {
  // WITHOUT arrays: one variable per item, repeated code for each one
  let item1 = "Pen",      price1 = 1.5;
  let item2 = "Notebook", price2 = 3.25;
  let item3 = "Ruler",    price3 = 0.99;
  let totalNoArray = price1 + price2 + price3;
  alert("Without arrays, total = £" + totalNoArray.toFixed(2));

  // WITH arrays: one list, one loop - works for 3 items or 1000
  let products = ["Pen", "Notebook", "Ruler"];
  let prices   = [1.5, 3.25, 0.99];
  let total = 0;

  alert("----- INVOICE -----");
  for (let i = 0; i < products.length; i++) {
    alert(products[i] + "  £" + prices[i].toFixed(2));
    total = total + prices[i];
  }
  alert("TOTAL: £" + total.toFixed(2));
});
