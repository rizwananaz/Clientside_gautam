// Slides 20-22: Boolean conversion - truthy and falsy values
registerExample(11, "Boolean conversion (truthy / falsy)", function () {
  let values = [0, "", null, undefined, NaN, 1, "hello", -5, [], {}];
  let labels = ["0", '""', "null", "undefined", "NaN", "1", '"hello"', "-5", "[]", "{}"];

  for (let i = 0; i < values.length; i++) {
    if (values[i]) {
      alert(labels[i] + " is truthy");
    } else {
      alert(labels[i] + " is falsy");
    }
  }

  if (0) { alert("This never runs - 0 is falsy"); }
  if (1) { alert("This always runs - 1 is truthy"); }

  // Passing a pre-evaluated boolean
  let year = 2015;
  let cond = (year == 2015); // equality evaluates to true or false
  if (cond) {
    alert("cond is " + cond);
  }
});
