// Slides 25-28: switch, with and without break
registerExample(13, "switch (with and without break)", function () {
  let a = 2 + 2;

  alert("--- WITH break ---");
  switch (a) {
    case 3:
      alert("Too small");
      break;
    case 4:
      alert("Exactly!");
      break;
    case 5:
      alert("Too large");
      break;
    default:
      alert("I don't know such values");
  }

  alert("--- WITHOUT break (falls through) ---");
  switch (a) {
    case 3:
      alert("Too small");
    case 4:
      alert("Exactly!");
    case 5:
      alert("Too big");
    default:
      alert("I don't know such values");
  }
});
