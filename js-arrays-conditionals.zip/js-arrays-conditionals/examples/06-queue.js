// Slide 10: Using an array as a queue (push to the end, shift from the start)
registerExample(6, "Queue (push + shift)", function () {
  let queue = [];
  queue.push("Customer 1");
  queue.push("Customer 2");
  queue.push("Customer 3");
  alert("Queue: " + queue);

  let served = queue.shift(); // first in, first out
  alert("Served: " + served + " | Still waiting: " + queue);

  served = queue.shift();
  alert("Served: " + served + " | Still waiting: " + queue);
});
