// Slide 29: switch uses STRICT equality (===) - type matters
registerExample(14, "switch type matters (strict equality)", function () {
  let arg = prompt("Enter a value? (try 0, 1, 2 or 3)", "3");

  switch (arg) {
    case "0":
    case "1":
      alert("One or zero");
      break;

    case "2":
      alert("Two");
      break;

    case 3: // number 3 - prompt returns the STRING "3", so this is dead code
      alert("Never executes!");
      break;

    default:
      alert("An unknown value");
  }
  alert('typeof arg is "' + typeof arg + '", so "3" === 3 is ' + ("3" === 3));
});
