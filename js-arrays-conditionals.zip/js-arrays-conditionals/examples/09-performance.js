// Slides 13-16: Why push/pop are fast and shift/unshift are slow
registerExample(9, "Performance: push/pop vs shift/unshift", function () {
  // Step-by-step of what shift has to do
  let fruits = ["Apple", "Orange", "Pear", "Lemon"];
  alert("Before shift: " + JSON.stringify(fruits) + " length=" + fruits.length);
  fruits.shift(); // 1) remove index 0  2) move every element left  3) update length
  alert("After shift:  " + JSON.stringify(fruits) + " length=" + fruits.length);

  let fruits2 = ["Apple", "Orange", "Pear", "Lemon"];
  fruits2.pop();  // just clear the last index and shorten length - nothing moves
  alert("After pop:    " + JSON.stringify(fruits2) + " length=" + fruits2.length);

  // A small timing experiment
  const N = 30000;
  function now() {
    return (typeof performance !== "undefined") ? performance.now() : Date.now();
  }

  let a = [], t = now();
  for (let i = 0; i < N; i++) a.push(i);
  for (let i = 0; i < N; i++) a.pop();
  let fast = now() - t;

  let b = [];
  t = now();
  for (let i = 0; i < N; i++) b.unshift(i);
  for (let i = 0; i < N; i++) b.shift();
  let slow = now() - t;

  alert("push/pop      " + N + " items: " + fast.toFixed(2) + " ms");
  alert("unshift/shift " + N + " items: " + slow.toFixed(2) + " ms");
  alert("Working at the END of an array is faster - nothing has to be renumbered.");
});
