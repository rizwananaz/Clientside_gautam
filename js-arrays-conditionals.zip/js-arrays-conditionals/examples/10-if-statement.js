// Slides 18-19: The if statement
registerExample(10, "if statement", function () {
  let year = Number(prompt("In which year was ECMAScript 2015 published?", "2015"));

  // single statement (works, but braces are recommended)
  if (year == 2015) alert("You are right!");

  // block with curly braces - recommended every time
  if (year == 2015) {
    alert("That's correct!");
    alert("You're so smart!");
  }
});
