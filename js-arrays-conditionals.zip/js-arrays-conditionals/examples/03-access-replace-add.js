// Slides 6-7: Accessing, replacing and adding by index
registerExample(3, "Access, replace and add by index", function () {
  let fruits = ["Apple", "Orange", "Plum"];

  alert(fruits[0]); // Apple
  alert(fruits[1]); // Orange
  alert(fruits[2]); // Plum

  fruits[2] = "Pear";  // replace
  alert("After replace: " + JSON.stringify(fruits)); // ["Apple","Orange","Pear"]

  fruits[3] = "Lemon"; // add new item
  alert("After add: " + JSON.stringify(fruits));     // ["Apple","Orange","Pear","Lemon"]
});
