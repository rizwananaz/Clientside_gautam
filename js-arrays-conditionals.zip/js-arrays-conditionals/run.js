// Run the examples in a terminal:
//   node run.js            -> runs all examples
//   node run.js 13         -> runs only example 13
//   node run.js 14 --answer=2   -> answers any prompt() with "2"
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const args = process.argv.slice(2);
const only = args.find(a => /^\d+$/.test(a));
const answerArg = args.find(a => a.startsWith("--answer="));
const answer = answerArg ? answerArg.split("=")[1] : null;

const context = vm.createContext({
  console,
  performance,
  JSON,
  alert: (msg) => console.log("  " + String(msg)),
  // In Node there is no pop-up, so prompt returns --answer or the default value
  prompt: (msg, def) => {
    const value = answer !== null ? answer : (def !== undefined ? String(def) : null);
    console.log("  [prompt] " + msg + " -> " + value);
    return value;
  },
});

vm.runInContext(fs.readFileSync(path.join(__dirname, "lib/register.js"), "utf8"), context);
const dir = path.join(__dirname, "examples");
for (const file of fs.readdirSync(dir).filter(f => f.endsWith(".js")).sort()) {
  vm.runInContext(fs.readFileSync(path.join(dir, file), "utf8"), context, { filename: file });
}

const list = vm.runInContext("EXAMPLES", context)
  .filter(ex => !only || ex.id === Number(only));

if (list.length === 0) {
  console.log("No example with number " + only + ". Use 1-14.");
  process.exit(1);
}
for (const ex of list) {
  console.log("\n=== " + ex.id + ". " + ex.title + " ===");
  ex.run();
}
