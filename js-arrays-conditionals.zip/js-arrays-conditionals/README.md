# JavaScript – Arrays and Conditional Statements

Runnable versions of every code example in the slides, one file per topic.

## Run in the browser
Double-click `index.html`. Pick an example on the left; output appears in the panel.
Tick **Use real alert() / prompt() pop-ups** to see the browser pop-ups exactly as in the slides.

## Run in the terminal (Node.js)
```
node run.js                  # run all examples
node run.js 13               # run only example 13
node run.js 14 --answer=2    # answer prompt() with "2"
```
(`npm start` also runs everything.) In Node, `alert()` prints to the console and
`prompt()` uses `--answer` or the example's default value.

## Files
| File | Slides | Topic |
|---|---|---|
| examples/01-what-is-an-array.js | 2–3 | Why arrays (invoice example) |
| examples/02-creating-arrays.js | 4–5 | `new Array()`, `[]`, var/let/const |
| examples/03-access-replace-add.js | 6–7 | Index access, replace, add |
| examples/04-length-and-alert.js | 8 | `length`, showing the whole array |
| examples/05-trailing-comma.js | 9 | Trailing comma |
| examples/06-queue.js | 10 | Queue with push + shift |
| examples/07-pop-push.js | 11 | pop & push |
| examples/08-shift-unshift.js | 12 | shift & unshift |
| examples/09-performance.js | 13–16 | Why push/pop are faster (with timing) |
| examples/10-if-statement.js | 18–19 | `if` and curly braces |
| examples/11-boolean-conversion.js | 20–22 | Truthy / falsy |
| examples/12-else-elseif.js | 23–24 | `else`, `else if` |
| examples/13-switch.js | 25–28 | `switch` with and without `break` |
| examples/14-switch-type.js | 29 | `switch` uses strict equality |

## Student exercises
1. Add a 4th product to the invoice in example 1 – how many lines change?
2. In example 13, remove one `break` and predict the output before running it.
3. In example 14, make case `3` work (hint: `case "3":` or `switch (Number(arg))`).
