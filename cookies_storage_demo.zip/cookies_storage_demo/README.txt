Cookies & Web Storage Demo

How to run:
1. Open this folder in VS Code and use Live Server, OR
2. In this folder run:  python -m http.server 8000
   then open http://localhost:8000/cookies_storage_demo.html

(Chrome blocks cookies when the file is opened directly as file://)
Press F12 > Application tab to watch cookies and storage change.
